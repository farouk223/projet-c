#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_RH_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_RR_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_M_RH_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_M_RR_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_RH_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_RH_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_RR_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_RR_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_S_RH_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_S_RR_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_A_RH_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_A_RR_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_reclamer_RH_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_OKH_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_OKF_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_reclamer_RR_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_modifier_RH_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_RR_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
